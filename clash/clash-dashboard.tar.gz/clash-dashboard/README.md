备份 https://github.com/Dreamacro/clash-dashboard/

使用说明

linux： 

git clone https://github.com/eorendel/clash-dashboard.git  /etc/clash-dashboard

修改配置文件config.yaml中相应字段为 external-ui: /etc/clash-dashboard

windows：

https://github.com/eorendel/clash-dashboard/archive/refs/heads/main.zip

下载解压到如d:\clash\clash-dashboard

修改配置文件config.yaml中相应字段为 external-ui: d:\clash\clash-dashboard


在浏览器里访问 http://127.0.0.1:9090/ui/
